const defaultConfig = require( '@wordpress/scripts/config/webpack.config' );
const path = require( 'path' );

module.exports = {
	...defaultConfig,
	entry: {
		'blocks/global-nav/index': path.resolve( process.cwd(), 'src/blocks/global-nav/index.js' ),
		'blocks/global-nav/view': path.resolve( process.cwd(), 'src/blocks/global-nav/view.js' ),
	},
    output: {
        path: path.resolve( process.cwd(), 'build' ),
        filename: '[name].js',
    }
};
