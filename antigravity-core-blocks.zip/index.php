<?php
/**
 * Plugin Name: Antigravity Core Blocks
 * Description: A suite of dynamic, server-side rendered blocks with a Storybook-first development workflow.
 * Version: 0.1.0
 * Author: Antigravity
 * License: GPL-2.0-or-later
 * Text Domain: antigravity-core
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Registers all blocks in the plugin.
 */
function antigravity_core_blocks_init()
{
    // Register the Global Navigation block
    register_block_type(__DIR__ . '/build/blocks/global-nav');
}
add_action('init', 'antigravity_core_blocks_init');
