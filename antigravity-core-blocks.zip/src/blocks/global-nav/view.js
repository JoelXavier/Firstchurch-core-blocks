import { createRoot } from '@wordpress/element';
import { GlobalNavigation } from '../../components/GlobalNavigation/GlobalNavigation';

document.addEventListener( 'DOMContentLoaded', () => {
    const roots = document.querySelectorAll( '.antigravity-global-nav-root' );

    roots.forEach( ( root ) => {
        const attributes = JSON.parse( root.dataset.attributes );
        
        if ( createRoot ) {
            createRoot( root ).render( <GlobalNavigation { ...attributes } /> );
        }
    } );
} );
