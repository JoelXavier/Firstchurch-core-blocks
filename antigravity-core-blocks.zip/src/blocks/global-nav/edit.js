import { __ } from '@wordpress/i18n';
import { useBlockProps, InspectorControls, MediaUpload, MediaUploadCheck } from '@wordpress/block-editor';
import { PanelBody, TextControl, Button, ToggleControl, TextareaControl } from '@wordpress/components';
import { GlobalNavigation } from '../../components/GlobalNavigation/GlobalNavigation';
import './editor.scss'; // Optional editor-specific styles

export default function Edit({ attributes, setAttributes }) {
	const { 
        logoTextPrimary, 
        logoTextSecondary, 
        logoId, 
        logoUrl, 
        ctaLabel, 
        ctaUrl,
        items,
        announcements,
        menuData
    } = attributes;

    // --- Handlers ---

    const updateItem = (index, key, value) => {
        const newItems = [...items];
        newItems[index][key] = value;
        setAttributes({ items: newItems });
    };

    const addItem = () => {
        setAttributes({ 
            items: [...items, { label: "New Link", url: "#", hasSubmenu: false }] 
        });
    };

    const removeItem = (index) => {
        const newItems = [...items];
        newItems.splice(index, 1);
        setAttributes({ items: newItems });
    };

    const updateAnnouncement = (index, value) => {
        const newAnnouncements = [...announcements];
        newAnnouncements[index] = value;
        setAttributes({ announcements: newAnnouncements });
    };

    const addAnnouncement = () => {
        setAttributes({ announcements: [...announcements, "New Announcement"] });
    };

    const removeAnnouncement = (index) => {
        const newAnnouncements = [...announcements];
        newAnnouncements.splice(index, 1);
        setAttributes({ announcements: newAnnouncements });
    };

    const onSelectLogo = (media) => {
        setAttributes({
            logoId: media.id,
            logoUrl: media.url // Or media.sizes.full.url
        });
    };

    const onRemoveLogo = () => {
        setAttributes({
             logoId: undefined,
             logoUrl: ''
        });
    };

	return (
		<div {...useBlockProps({ className: 'antigravity-global-nav-editor' })}>
            
            {/* 1. Sidebar Controls */}
            <InspectorControls>
                
                <PanelBody title={__('Identity', 'antigravity-core-blocks')} initialOpen={true}>
                    <MediaUploadCheck>
                        <MediaUpload
                            onSelect={onSelectLogo}
                            allowedTypes={['image']}
                            value={logoId}
                            render={({ open }) => (
                                <div className="editor-logo-upload">
                                    {logoUrl && <img src={logoUrl} alt="Logo" style={{ maxWidth: '100%', marginBottom: '10px' }} />}
                                    <div style={{ display: 'flex', gap: '10px' }}>
                                        <Button variant="secondary" onClick={open}>
                                            {logoUrl ? __('Replace Logo', 'antigravity-core-blocks') : __('Upload Logo', 'antigravity-core-blocks')}
                                        </Button>
                                        {logoUrl && (
                                            <Button variant="link" isDestructive onClick={onRemoveLogo}>
                                                {__('Remove', 'antigravity-core-blocks')}
                                            </Button>
                                        )}
                                    </div>
                                </div>
                            )}
                        />
                    </MediaUploadCheck>
                    <br />
                    <TextControl
                        label={__('Primary Name', 'antigravity-core-blocks')}
                        value={logoTextPrimary}
                        onChange={(val) => setAttributes({ logoTextPrimary: val })}
                    />
                    <TextControl
                        label={__('Secondary Name', 'antigravity-core-blocks')}
                        value={logoTextSecondary}
                        onChange={(val) => setAttributes({ logoTextSecondary: val })}
                    />
                </PanelBody>

                <PanelBody title={__('Top Navigation', 'antigravity-core-blocks')} initialOpen={false}>
                    {items.map((item, index) => (
                        <div key={index} className="nav-item-control" style={{ borderBottom: '1px solid #ddd', paddingBottom: '10px', marginBottom: '10px' }}>
                            <TextControl
                                label={`Link ${index + 1} Label`}
                                value={item.label}
                                onChange={(val) => updateItem(index, 'label', val)}
                            />
                            <TextControl
                                label="URL"
                                value={item.url}
                                onChange={(val) => updateItem(index, 'url', val)}
                            />
                            <ToggleControl
                                label="Has Submenu?"
                                checked={item.hasSubmenu}
                                onChange={(val) => updateItem(index, 'hasSubmenu', val)}
                            />
                            <Button isDestructive variant="link" onClick={() => removeItem(index)}>
                                Remove
                            </Button>
                        </div>
                    ))}
                    <Button variant="primary" onClick={addItem}>Add Link</Button>
                </PanelBody>

                <PanelBody title={__('Announcements', 'antigravity-core-blocks')} initialOpen={false}>
                    {announcements.map((text, index) => (
                         <div key={index} style={{ display: 'flex', gap: '5px', marginBottom: '5px' }}>
                             <TextControl
                                value={text}
                                onChange={(val) => updateAnnouncement(index, val)}
                                style={{ flex: 1 }}
                             />
                             <Button isDestructive icon="trash" onClick={() => removeAnnouncement(index)} />
                         </div>
                    ))}
                    <Button variant="secondary" onClick={addAnnouncement}>Add Announcement</Button>
                </PanelBody>

                 <PanelBody title={__('Call to Action', 'antigravity-core-blocks')} initialOpen={false}>
                    <TextControl
                        label="Button Label"
                        value={ctaLabel}
                        onChange={(val) => setAttributes({ ctaLabel: val })}
                    />
                    <TextControl
                        label="Button URL"
                        value={ctaUrl}
                        onChange={(val) => setAttributes({ ctaUrl: val })}
                    />
                </PanelBody>

                 <PanelBody title={__('Mega Menu Data', 'antigravity-core-blocks')} initialOpen={false}>
                    <p style={{ fontSize: '11px', color: '#666' }}>
                        For Phase 1, the Mega Menu data is managed via this JSON object. In future phases, this will be connected to real WordPress menus and posts.
                    </p>
                    <TextareaControl
                        label="Menu Data JSON"
                        value={JSON.stringify(menuData, null, 2)}
                        onChange={(val) => {
                            try {
                                setAttributes({ menuData: JSON.parse(val) });
                            } catch (e) {
                                // invalid json, ignore
                            }
                        }}
                        rows={10}
                    />
                </PanelBody>

            </InspectorControls>

            {/* 2. Editor Canvas Preview */}
			<GlobalNavigation 
                logoTextPrimary={logoTextPrimary}
                logoTextSecondary={logoTextSecondary}
                ctaLabel={ctaLabel}
                items={items}
                announcements={announcements}
                menuData={menuData}
                logoSrc={logoUrl}
            />
		</div>
	);
}
